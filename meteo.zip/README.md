# Meteo
Internship project ( HTML / PHP / CSS / JS / SQL )

A little project for my 2nd year Internship. Nothing crazy.

Never did HTML / PHP / CSS / JS before that, only C / SQL / JAVA. 
