<?php include("/ressources/config.php"); 

$bddCo = new bddCo();
$services = $bddCo->getListServices();

if(isset($_REQUEST['action'])){
    $shib = new ShibLogin();
    if($_REQUEST['action'] == 'shiblogin'){
        $shib->req_shiblogin();
    } else if ($_REQUEST['action'] == 'login'){
        $shib->req_login();
    }
}

include("./template/dashboard.php"); ?>